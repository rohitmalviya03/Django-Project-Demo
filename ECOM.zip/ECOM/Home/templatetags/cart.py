from django import template

register = template.Library()

@register.filter(name='productExits')


def productExits(product,cart):
    keys=cart.keys()
    for ids in keys:
        if int(ids) == product.id:
            return True
        

    return False  

@register.filter(name='quantity')
def quantity(product,cart):
    keys=cart.keys()
   
    for i in keys:
       if(product.id == int(i)):
          return cart.get(i)
       

@register.filter(name='cartprice')
def cartprice(product,cart):
    keys=cart.keys()
    
    for i in keys:
       if(product.id == int(i)):
          price=product.price*cart.get(i)
          print(product.id,price)
          return price
    

       
    
